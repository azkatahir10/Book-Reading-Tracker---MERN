app.get("/books", async (req, res) => {
    try {
      const books = await Book.find();
      res.status(200).json(books);
    } catch (err) {
      res.status(500).json({ error: "Error fetching books" });
    }
  });
  
  app.post("/books", async (req, res) => {
    try {
      const newBook = new Book(req.body);
      const savedBook = await newBook.save();
      res.status(201).json(savedBook);
    } catch (err) {
      res.status(500).json({ error: "Error saving book" });
    }
  });
  
  app.put("/books/:id", async (req, res) => {
    try {
      const updatedBook = await Book.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      });
      res.status(200).json(updatedBook);
    } catch (err) {
      res.status(500).json({ error: "Error updating book" });
    }
  });
  
  app.delete("/books/:id", async (req, res) => {
    try {
      await Book.findByIdAndDelete(req.params.id);
      res.status(200).json({ message: "Book deleted successfully" });
    } catch (err) {
      res.status(500).json({ error: "Error deleting book" });
    }
  });
  
  // Start server
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
  
  
  