import React, { useState } from "react";
import "../scss/dashboard.scss";

function Dashboard() {
  const [books, setBooks] = useState([]);
  const [newBook, setNewBook] = useState({ title: "", author: "", genre: "", progress: "" });

  const addBook = () => {
    setBooks([...books, { ...newBook, id: Date.now() }]);
    setNewBook({ title: "", author: "", genre: "", progress: "" });
  };

  const updateBook = (id, updatedBook) => {
    setBooks(books.map((book) => (book.id === id ? updatedBook : book)));
  };

  const removeBook = (id) => {
    setBooks(books.filter((book) => book.id !== id));
  };

  return (
    <div className="dashboard-container">
      <h1>Reading Tracker</h1>
      <div className="add-book-form">
        <input
          type="text"
          placeholder="Book Title"
          value={newBook.title}
          onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
        />
        <input
          type="text"
          placeholder="Author"
          value={newBook.author}
          onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
        />
        <input
          type="text"
          placeholder="Genre"
          value={newBook.genre}
          onChange={(e) => setNewBook({ ...newBook, genre: e.target.value })}
        />
        <input
          type="number"
          placeholder="Progress (%)"
          value={newBook.progress}
          onChange={(e) => setNewBook({ ...newBook, progress: e.target.value })}
        />
        <button onClick={addBook}>Add Book</button>
      </div>

      <div className="books-list">
        {books.map((book) => (
          <div className="book-item" key={book.id}>
            <h3>{book.title}</h3>
            <p>Author: {book.author}</p>
            <p>Genre: {book.genre}</p>
            <p>Progress: {book.progress}%</p>
            <button onClick={() => removeBook(book.id)}>Remove</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Dashboard;
